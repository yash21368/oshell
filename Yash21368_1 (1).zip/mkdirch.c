#include<stdio.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<errno.h>
#include<unistd.h>
#include<string.h>

int main(int argv,char *argc[])
{
	if(mkdir(argc[1],0777)==0)
	{
		if(strcmp("rwx",argc[3])==0)
		{
		chmod(argc[1],0777);
		}
		else if(strcmp("rw",argc[3])==0)
		{
		chmod(argc[1],0666);
		}
	}
        else
        {
        	perror("error");
        }
        return 0;       
}
