#include<stdio.h>
#include<string.h>
#include<stdlib.h>

int main(int argc,char *argv[])
{
    FILE* f;
    char data[1024];
    int lno=1;
    f=fopen(argv[1],"r");
    if(f==NULL)
    {
        printf("File invalid\n");
    }
    if(strcmp(argv[2],"-n")==0)
    {
        while(fgets(data,sizeof(data),f))
        {
            printf("%d %s",lno,data);
            if(strchr(data,'\n'))
            {
                lno++;
            }
        }
    }
    else if(strcmp(argv[2],"-e")==0)
    {
    	char d;
    	d=fgetc(f);
        while(d!=EOF)
        {      
            if(d!='\n')
            {
            printf("%c",d);  
            }  
            else
            {
            printf("$\n");  
            }
            d=fgetc(f);
        }
    }
    return 0;

}
