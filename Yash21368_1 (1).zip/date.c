#include<stdio.h>
#include<time.h>
#include<string.h>

int main(int argc,char *argv[])
{
    time_t t;
    time(&t);
    if(argc==1)
    {
    printf("%s",ctime(&t));
    }
    else 
    {
        if(strcmp(argv[1],"-u")==0)
        {
            struct tm *utime;
            t=time(NULL);
            utime=gmtime(&t);
            printf("%s",asctime(utime));
        }
        else if(strcmp(argv[1],"-R")==0)
        {
            char string[26];
            struct tm *utime;
            t=time(NULL);
            utime=localtime(&t);
            strftime(string,26,"%Y-%m-%d %H:%M:%S",utime);
            puts(string);
        }
    }
    return 0;
}