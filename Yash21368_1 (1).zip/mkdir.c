#include<stdio.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<errno.h>
#include<string.h>

int main(int argv,char *argc[])
{
    struct stat s={0};
    if(argv==1)
    {
    if(stat(argc[1],&s)==-1)
        {   
            mkdir(argc[1],0777);
        }    
        else
        {
            fprintf(stderr,"Error: %d\n",errno);
            perror("ya.sh");        
        }
    }
    else
    {
    if(stat(argc[1],&s)==-1)
	{
		mkdir(argc[1],0777);
		if(strcmp("rwx",argc[2])==0)
		{
		printf("in\n");
		chmod(argc[1],0777);
		}
		else if(strcmp("rw",argc[2])==0)
		{
		chmod(argc[1],0666);
		}
	}
        else
        {
        	perror("error");
        }
    }    
    return 0;
}
