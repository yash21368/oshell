#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<sys/wait.h>
#include<unistd.h>
#include<pthread.h>

int main(int argc,char **argv)
{
 	printf("\tWelcome to ya.sh\n");
 	char cmd[100];
 	char ab[100][100];
 	int u=0;
 	while(1)
 	{
 	printf("ya.sh>");
 	scanf("%[^\n]%*c",cmd);
 	int wsp=0;
 	int i=0;
 	while(i<=cmd[i])
 	{
 		if(cmd[i]==' ')
 		{
 			wsp++;
 		}
 		i++;
 	}
 	if(wsp==0)
 	{
 		if(strcmp(cmd,"cd")==0)
 		{
 			continue;
 		}
 		else if(strcmp(cmd,"ls")==0)
 		{
 			pid_t pid;
			pid=fork();
			if(pid == 0)
			{
				int ty=execl("ls","ls",NULL);
			 	if(ty==-1)
			 	{printf("Empty directory\n");}
			}
			else
			{
				wait(NULL);
			}
			 continue;
	 }
	 else if(strcmp(cmd,"cat")==0)
	 {
	 printf("usage: cat [-e | -n] [filename]....\n");
	 continue;
	 }
	 else if(strcmp(cmd,"echo")==0)
	 {
	 printf("\n");
	 continue;
	 }
	 else if(strcmp(cmd,"pwd")==0)
	 {
	 char pwd[1024];
	 getcwd(pwd, sizeof(pwd));
	 printf("%s\n", pwd);
	 continue;
	 }
     else if(strcmp(cmd,"date")==0)
     {   
     pid_t pid;
     pid=fork();
     if(pid==0)
     {
     execl("date","date",NULL);
     }
     else
     {
     wait(NULL);
     }
     continue;
    }
	 else if(cmd[0]=='d' && cmd[1]=='a' && cmd[2]=='t' && cmd[3]=='e')
	 {
     if(cmd[4]=='&' && cmd[5]=='t')
     {
        pthread_t tpid;
        pthread_create(&tpid,NULL,(void*)system,cmd);
        pthread_join(tpid,NULL);
     }
	 }
	 else if(strcmp(cmd,"mkdir")==0)
	 {
	 printf("usage: mkdir [-pv] [-m mode] directory_name ...\n");
	 }
	 else if(strcmp(cmd,"rm")==0)
	 {
	 printf("usage: rm [-v | -i] [-dIPRrvWx] file ...\n");
	 }
	 else if(strcmp(cmd,"exit")==0){
	 exit(0);
	 }
	 else
	 {
	 printf("ya.sh: command not found: %s\n",cmd);
	 }
	 }
	 else if(wsp==1)
	 {
	 if(cmd[0]=='c' && cmd[1]=='d')
	 {
	 char c[1024];
	 int j=0;
	 for(int i=3;cmd[i]!='\0';i++)
	 {
	 c[j]=cmd[i];
	 j++;
	 }
	 c[j]='\0';
	 if(cmd[3]=='-')
	 {
	 chdir(ab[u-2]);
	 u--;
	 }
	 else if(cmd[3]=='~')
	 {
	 chdir("/home/gum");
	 strcpy(ab[u],"/home/gum");
	 u++;
	 }
	 else if(strlen(c)!=0)
	 { 
	 chdir(c);
	 strcpy(ab[u],c);
	 u++;
	 }
	 else
	 {
	 printf("Null arguement\n");
	 }
	 continue;
	 }
	 else if(cmd[0]=='p' && cmd[1]=='w' && cmd[2]=='d')
	 {
	 if(cmd[4]=='-')
	 {
	 if(cmd[5]=='L')
	 {
	 char *temp=getenv("PWD");
	 printf("%s\n",temp);
	 continue;
	 }
	 else if(cmd[5]=='P')
	 {
	 char pwd[1024];
	 getcwd(pwd, sizeof(pwd));
	 printf("%s\n", pwd);
	 continue;
	 }
	 }
	 }
	 else if(cmd[0]=='e' && cmd[1]=='c' && cmd[2]=='h' && cmd[3]=='o')
	 {
	 if(cmd[6]=='h')
	 {
	 printf("NAME\necho: write arguments to the standard output\nSYNOPSIS\necho [-n] [string ...]\nDESCRIPTION\nthe following option is available\n-n: dp not output the trailing newline\n");
	 }
	 else
	 {
	 char c[1024];
	 int j=0;
	 for(int i=5;cmd[i]!='\0';i++)
	 {
	 c[j]=cmd[i];
	 j++;
	 }
	 c[j]='\0';
	 printf("%s\n",c);
	 }
	 }
	 else if(cmd[0]=='c' && cmd[1]=='a' && cmd[2]=='t')
	 {
	 printf("usage: cat [-e | -n] [filename]....\n");
	 continue;
	 }
	 else if(cmd[0]=='l' && cmd[1]=='s')
	 {
	 if(cmd[3]=='-')
	 {
	 if(cmd[4]=='a')
	 {
	 pid_t pid;
	 pid=fork();
	 if(pid==0)
	 {
	 execl("ls","ls","-a",NULL);
	 }
	 else
	 {
	 wait(NULL);
	 }
	 continue;
	 }
	 else if(cmd[4]=='n')
	 {
	 pid_t pid;
	 pid=fork();
	 if(pid==0)
	 {
	 execl("ls","ls","-n",NULL);
	 }
	 else
	 {
	 wait(NULL);
	 }
	 continue; 
	 }
	 }
	 }
	 else if(cmd[0]=='d' && cmd[1]=='a' && cmd[2]=='t' && cmd[3]=='e')
	 {
	 
	 if(cmd[5]=='-')
	 {
	 if(cmd[6]=='u')
	 {
	 pid_t pid;
	 pid=fork();
	 if(pid==0)
	 {
	 execl("date","date","-u",NULL);
	 }
	 else
	 {
	 wait(NULL);
	 }
	 continue;
	 }
	 else if(cmd[6]=='R')
	 {
	 pid_t pid;
	 pid=fork();
	 if(pid==0)
	 {
	 execl("date","date","-R",NULL);
	 }
	 else
	 {
	 wait(NULL);
	 }
	 continue;
	 }
	 else
	 {
	 printf("illegal option -%c\n",cmd[6]);
	 continue;
	 }
	 }
	 else{printf("wrong syntax\n");}
	 }
	 else if(cmd[0]=='r' && cmd[1]=='m')
	 {
	 char c[1024];
	 int j=0;
	 for(int i=3;cmd[i]!='\0';i++)
	 {
	 c[j]=cmd[i];
	 j++;
	 }
	 c[j]='\0';
	 pid_t pid;
	 pid=fork();
	 if(pid==0)
	 {
	 execl("rmm","rmm",c,"-v",NULL);
	 }
	 else
	 {
	 wait(NULL);
	 }
	 continue;
	 }
	 else if(cmd[0]=='m' && cmd[1]=='k' && cmd[2]=='d' && cmd[3]=='i' && cmd[4]=='r')
	 {
	 char c[1024];
	 int j=0;
	 for(int i=6;cmd[i]!='\0';i++)
	 {
	 c[j]=cmd[i];
	 j++;
	 } 
	 c[j]='\0';
	 pid_t pid;
	 pid=fork();
	 if(pid==0)
	 {
	 execl("mkdir","mkdir",c,NULL);
	 }
	 else
	 {
	 wait(NULL);
	 }
	 continue; 
	 }
	 else
	 {
	 printf("ya.sh: command not found: %s\n",cmd);
	 }

	 }
	 else if(wsp==2)
	 {
	 if(cmd[0]=='c' && cmd[1]=='d')
	 {
	 printf("wrong syntax\n");
	 }

	 else if(cmd[0]=='p' && cmd[1]=='w' && cmd[2]=='d')
	 {
	 printf("wrong syntax\n");
	 }
	 
	 else if(cmd[0]=='l' && cmd[1]=='s')
	 {
	 printf("wrong syntax\n");
	 }
	 
	 else if(cmd[0]=='d' && cmd[1]=='a' && cmd[2]=='t' && cmd[3]=='e')
	 {	 printf("wrong syntax\n");}
	 
	 else if(cmd[0]=='e' && cmd[1]=='c' && cmd[2]=='h' && cmd[3]=='o')
	 {
	 char c[1024];
	 int j=0;
	 for(int i=8;cmd[i]!='\0';i++)
	 {
	 c[j]=cmd[i];
	 j++;
	 }
	 c[j]='\0';
	 if(cmd[5]=='-')
	 {
	 if(cmd[6]=='n')
	 {
	 printf("%s",c);
	 }
	 
	 else
	 {
	 printf("illegal option -%c\n",cmd[6]);
	 continue;
	 }
	 }
	 else
	 {
	 printf("wrong syntax\n");
	 }
	 }
	 else if(cmd[0]=='c' && cmd[1]=='a' && cmd[2]=='t')
	 {
	 char c[1024];
	 int j=0;
	 for(int i=7;cmd[i]!='\0';i++)
	 {
	 c[j]=cmd[i];
	 j++;
	 }
	 c[j]='\0';
	 if(cmd[4]=='-')
	 {
	 if(cmd[5]=='n')
	 {
	 pid_t pid;
	 pid=fork();
	 if(pid==0)
	 {
	 execl("cat","cat",c,"-n",NULL);
	 }
	 else
	 {
	 wait(NULL);
	 }
	 }
	 else if(cmd[5]=='e')
	 {
	 pid_t pid;
	 pid=fork();
	 if(pid==0)
	 {
	 execl("cat","cat",c,"-e",NULL);
	 }
	 else
	 {
	 wait(NULL);
	 }
	 }
	 else
	 {
	 printf("illegal option -%c\n",cmd[5]);
	 continue;
	 }
	 }
	 else
	 {
	 printf("wrong syntax\n");
	 }
	 continue;
	 }
	 else if(cmd[0]=='r' && cmd[1]=='m')
	 {
	 char c[1024];
	 int j=0;
	 for(int i=6;cmd[i]!='\0';i++)
	 {
	 c[j]=cmd[i];
	 j++;
	 }
	 c[j]='\0';
	 if(cmd[3]=='-')
	 {
	 if(cmd[4]=='i')
	 {
	 pid_t pid;
	 pid=fork();
	 if(pid==0)
	 {
	 execl("rmm","rmm",c,"-i",NULL);
	 }
	 else
	 {
	 wait(NULL);
	 }
	 continue;
	 }
	 else if(cmd[4]=='v')
	 {
	 pid_t pid;
	 pid=fork();
	 if(pid==0)
	 {
	 execl("rmm","rmm",c,"-v",NULL);
	 }
	 else
	 {
	 wait(NULL);
	 }
	 }
	 else
	 {
	 printf("illegal option -%c\n",cmd[4]);
	 }
	 }
	 else
	 {
	 printf("wrong syntax\n");
	 }
	 }
	 else if(cmd[0]=='m' && cmd[1]=='k' && cmd[2]=='d' && cmd[3]=='i' && cmd[4]=='r')
	 {
	 char c[1024];
	 int j=0;
	 for(int i=9;cmd[i]!='\0';i++)
	 {
	 c[j]=cmd[i];
	 j++;
	 } 
	 c[j]='\0';
	 if(cmd[6]=='-')
	 {
	 if(cmd[7]=='v')
	 {
	 pid_t pid;
	 pid=fork();
	 if(pid==0)
	 {
	 execl("mkdir","mkdir",c,NULL);
	 }
	 else
	 {
	 wait(NULL);
	 }
	 printf("created directory: %s\n",c);
	 continue; 
	 }
	 else if(cmd[7]=='m')
	 {
	 if(cmd[8]=='=')
	 {
	 char b[1024];
	 int k;
	 for(int i=13;cmd[i]!='\0';i++)
	 {
	 b[k]=cmd[i];
	 k++;
	 }
	 b[k]='\0';
	 pid_t pid;
	 pid=fork();
	 if(pid==0)
	 {
	 execl("mkdir","mkdir",b,"rwx",NULL);
	 }
	 else
	 {
	 wait(NULL);
	 }
	 continue;
	 }
	 else
	 {
	 printf("usage: mkdir [-m mode] directory_name ...\n");
	 }
	 }
	 else
	 {
	 printf("illegal option -%c\n",cmd[4]);
	 }
	 
	 }
	 else
	 {printf("wrong syntax\n");}
	 }
	 else
	 {printf("ya.sh: command not found\n");}
	 } 
	 } 
	return 0;
	} 

