#include<stdio.h>
#include<dirent.h>
#include<string.h>

int main(int argc,char *argv[])
{
    struct dirent *dr;
    DIR *d=opendir(".");
    if(d == NULL)
    {
        return -1;
    }
    if(argc==1)
    {
        while((dr=readdir(d))!=NULL)
        {
            if(dr->d_name[0]!='.')
            {printf("%s\n",dr->d_name);}
        }
    }
    else
    {
        if(strcmp(argv[1],"-a")==0)
        {
            while((dr=readdir(d))!=NULL)
        {
            printf("%s\n",dr->d_name);
        }
        }

        else if(strcmp(argv[1],"-n")==0)
        {
            while((dr=readdir(d))!=NULL)
            {
                printf("%s %lu %hhu\n",dr->d_name,dr->d_ino,dr->d_type);
            }
            
        }
    }
    closedir(d);
    return 0;
}
