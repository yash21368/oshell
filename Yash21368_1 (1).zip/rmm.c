#include<stdio.h>
#include<stdlib.h>
#include<errno.h>
#include<string.h>

int main(int argv,char *argc[])
{
   
        if(strcmp(argc[2],"-i")==0)
        {
        printf("remove(Y/N)?");
        char c[1];
        scanf("%s",c);
        if(strcmp(c,"Y")==0)
        {
            if(remove(argc[1])!=0)
            {
            	printf("in\n");
                fprintf(stderr,"Error: %d\n",errno);
                perror("ya.sh");
            }
            else
            {
                return 0;
            }
        }
        else if(strcmp(c,"N")==0)
        {
            return 0;
        }
        }
        else if(strcmp(argc[2],"-v")==0)
        {
            if(remove(argc[1])!=0)
            {
                fprintf(stderr,"Error: %d\n",errno);
                perror("ya.sh");
            }
            else
            {
                printf("%s\n",argc[1]);
                return 0;
            }
        }
 
    }
}    
